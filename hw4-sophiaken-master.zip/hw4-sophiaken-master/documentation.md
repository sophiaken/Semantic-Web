# HW4 notes

Steps of Creating a myontology.ttl:

1)Created classes and subclasses for the given abstract and physical objects.

2)Developed a list of object properties that will be appropriate for the classes in the class heirarchy.

3)Developed a list of data properties for the provided classes.

4)Added the contraints at all essential places inorder to satisfy the conditions of the ontology.

5)Annotated the classes, Properties with comments and labels.


Steps that I used to create mydata.ttl"

1) Created several instances that I thought will be appropriate for the inputting ontology file.

2)Imported the ontology onto the data file.

3)Estabilished few relation on the data file using ontology file such as hasParent and hasChild  relations.


4)Started the reasoner inorder to check that all the constraints are satisfied or not.The individual types are infered as adults, children,infants.

5)Several class inferences and object inferences were made by the reasoner.


