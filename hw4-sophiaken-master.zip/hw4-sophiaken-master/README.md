# hw4_starter
Starter repository for HW4

You can checkout the peeps ontology at https://github.com/UMBC-CMSC-491-691-F17/peeps which includes an ontology (peeps.owl) and a file of instances (mypeeps.owl). These can be used as examples to get you started. We recommend that you load mypeeps.owl into Protege and view the data and schema, rather than just looking at the serialization (which is in Turtle).

The HW4 repository has stubs for three files you will complete for the homework:

* myontology.owl
* mydata.owl
* documentation.html
