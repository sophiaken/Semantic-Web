# YOUR NAME, YOUR_ID@UMBC.EDU

describe the additional facts you added to your myfamily.ttl file

1)The first fact that I have included in the myfamily.ttl file is foaf:nick i.e nicknames of each and every person except my grandfather and grandmother.
2)The second fact that I have included in the myfamily.ttl file is the phone number for everyone except my grandparents.
3)The third fact that I have included is everyone's age .

The Rules in myrules.n3 file

1)Implemented the foaf:knows rule for parents,children,spouse and sibling.
2)Implemented the additional rule for age i.e elder to others in the family and younger to others in the family.
3)Implemented the additional rule for phone number i.e NO one's phone number is similar(Unique ID).



