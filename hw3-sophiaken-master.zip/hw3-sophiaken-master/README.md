# CMSC 491/691 Fall 2018 HW3

Complete and push the following files:

* myfamily.ttl - a file that describes your family
* myrules.n3 - additional rules as required by the homework
* myfamily_facts.ttl - the file generated with make from your Makefile
* Makefile - push if you have modified it
* myhw3.md -- describe the additional facts you added to your myfamily.ttl file
